import Entity.*;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        try {
        
        ArrayList<Food> menu = new ArrayList<>();
        
      
        menu.add(new FastFood("Burger", 420.0, "Large")); // 0
        menu.add(new Drinks("Milk Shake", 119.0, "Cold")); // 1
        menu.add(new FastFood("Pizza", 699.0, "Medium")); // 2
        menu.add(new Drinks("Orio Shake", 129.0, "Cold")); // 3
        menu.add(new FastFood("Chicken Fry", 199.0, "Medium")); // 4
        menu.add(new FastFood("Ice Cream", 67.0, "Small")); // 5
        menu.add(new Drinks("Cold Coffee", 99.0, "Cold")); // 6
        menu.add(new FastFood("Fries", 99.0, "Large")); // 7
        menu.add(new Drinks("Latte", 199.0, "Hot")); // 8
        menu.add(new Drinks("Mojo", 69.0, "Cold")); // 9

        
        new MainGUI(menu);
        } catch (Exception e) { 
            System.out.println("An unexpected error occurred in the main method.");
            e.printStackTrace(); 
        }
    }
}
