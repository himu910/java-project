import Entity.*;
import File.FileIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class MainGUI extends JFrame implements ActionListener {
    
    private ArrayList<Food> menu;
 
    private ArrayList<Order> orderHistory;
    
    private JTextArea displayArea;
    private JTextField foodNumbersField;
    private JButton viewMenuBtn, calculateTotalBtn, placeOrderBtn, loadOrdersBtn;
    
    private Font font15 = new Font("Consolas", Font.BOLD, 12);
    
    public MainGUI(ArrayList<Food> initialMenu) {
        super("Food Ordering System");
        this.menu = initialMenu;
        this.orderHistory = new ArrayList<>();
        createGUI();
        viewMenu();
    }

    private void createGUI() {
        
        this.setSize(600, 500);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null); 
        
        JLabel title = new JLabel("Welcome to the Food Ordering System");
        title.setBounds(10, 10, 580, 30);
        title.setFont(new Font("Consolas", Font.BOLD, 20));
        this.add(title);
        
      
        displayArea = new JTextArea();
        displayArea.setEditable(false);
        displayArea.setFont(font15);
        JScrollPane scrollPane = new JScrollPane(displayArea);
        scrollPane.setBounds(10, 50, 565, 250);
        this.add(scrollPane);
        
       
        JLabel inputLabel = new JLabel("Enter Food Numbers (N S N):");
        inputLabel.setBounds(10, 310, 200, 30);
        inputLabel.setFont(font15);
        this.add(inputLabel);
        
        foodNumbersField = new JTextField("");
        foodNumbersField.setBounds(10, 340, 300, 30);
        foodNumbersField.setFont(font15);
        foodNumbersField.addActionListener(this);
        this.add(foodNumbersField);
        
        
        viewMenuBtn = new JButton("View Menu");
        viewMenuBtn.setBounds(10, 380, 150, 30);
        viewMenuBtn.setFont(font15);
        viewMenuBtn.addActionListener(this);
        this.add(viewMenuBtn);
        
        calculateTotalBtn = new JButton("Calculate Total");
        calculateTotalBtn.setBounds(170, 380, 150, 30);
        calculateTotalBtn.setFont(font15);
        calculateTotalBtn.addActionListener(this);
        this.add(calculateTotalBtn);
        
        placeOrderBtn = new JButton("Place Order");
        placeOrderBtn.setBounds(330, 380, 150, 30);
        placeOrderBtn.setFont(font15);
        placeOrderBtn.addActionListener(this);
        this.add(placeOrderBtn);
        
        loadOrdersBtn = new JButton("Load History");
        loadOrdersBtn.setBounds(490, 380, 85, 30);
        loadOrdersBtn.setFont(font15);
        loadOrdersBtn.addActionListener(this);
        this.add(loadOrdersBtn);
        
        this.setVisible(true);
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == viewMenuBtn) {
            viewMenu();
        } else if (e.getSource() == calculateTotalBtn) {
            calculateTotal();
        } else if (e.getSource() == placeOrderBtn) {
            placeOrder();
        } else if (e.getSource() == loadOrdersBtn) {
            loadOrders();
        }
    }
    
    
    private void viewMenu() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== MENU ===\n\n");
        for (int i = 0; i < menu.size(); i++) {
            Food f = menu.get(i);
            sb.append("[").append(i).append("] ").append(f.getFoodName())
              .append(" - ").append(String.format("%.2f", f.getPrice())).append(" Tk")
              .append("\n");
        }
        displayArea.setText(sb.toString());
    }
    
    private void calculateTotal() {
        String input = foodNumbersField.getText().trim();
        if (input.isEmpty()) {
            displayArea.setText("Please enter food numbers to calculate total.");
            return;
        }
        
        String[] nums = input.split("\\s+");
        double total = 0.0;
        
        try {
            for (String num : nums) {
                int index = Integer.parseInt(num.trim());
                if (index >= 0 && index < menu.size()) {
                    total += menu.get(index).getPrice();
                } else {
                   
                    JOptionPane.showMessageDialog(this, "Invalid food number: " + num, "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
            displayArea.setText("Selected Items: " + input + "\n\n" +
                                "Calculated Total: " + String.format("%.2f", total) + " Tk");
        } catch (NumberFormatException ex) {
            
            JOptionPane.showMessageDialog(this, "Error: Please enter only numbers separated by spaces.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void placeOrder() {
        String input = foodNumbersField.getText().trim();
        if (input.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select items before placing an order.", "Order Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        Order newOrder = new Order();
        String[] nums = input.split("\\s+");
        
        try {
            for (String num : nums) {
                int index = Integer.parseInt(num.trim());
                if (index >= 0 && index < menu.size()) {
                    newOrder.addFood(menu.get(index));
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid food number: " + num + ". Order cancelled.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
            
            orderHistory.add(newOrder);
            FileIO.saveInFile(newOrder.toString());
            
            displayArea.setText("Order Placed Successfully!\n\n" + newOrder.toString());
            foodNumbersField.setText("");
            
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Error: Please enter only numbers separated by spaces.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void loadOrders() {
        String data = FileIO.loadFromFile();
        displayArea.setText("=== Order History ===\n\n" + data);
    }
}
