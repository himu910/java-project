package Entity;

public class FastFood extends Food {
    private String portionSize;

    public FastFood() {}

    public FastFood(String foodName, double price, String portionSize) {
        super(foodName, price);
        this.portionSize = portionSize;
    }

    public void setPortionSize(String portionSize) {
        this.portionSize = portionSize;
    }

    public String getPortionSize() {
        return portionSize;
	}
	
    public String getFoodDetails() {
        return "-------------------------\n" +
               "Food Name: " +getFoodName()+ "\n" +
               "Price: " +getPrice()+ "\n" +
               "PortionSize: " +portionSize+ "\n";
    }

}
