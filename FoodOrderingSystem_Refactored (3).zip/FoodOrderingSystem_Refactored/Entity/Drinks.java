package Entity;

public class Drinks extends Food{
	private String temparatureType;
	
	public Drinks(){}
	
	public Drinks(String foodName, double price, String temparatureType){
		super(foodName, price);
		this.temparatureType = temparatureType;
	}
	
	public void setTemparatureType(String temparatureType){
		this.temparatureType=temparatureType;
	}
	public String getTemparatureType(){
		return temparatureType;
	}
	 public String getFoodDetails() {
        return "-------------------------\n" +
               "Drinks Name: " +getFoodName()+ "\n" +
               "Price: " +getPrice()+ "\n" +
               "Temparature: " +temparatureType+ "\n";
    }
}
