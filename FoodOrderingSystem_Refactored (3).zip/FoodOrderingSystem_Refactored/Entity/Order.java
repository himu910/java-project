package Entity;

import java.util.ArrayList;

public class Order {
    private static int nextOrderId = 1;
    private int orderId;
 
    private ArrayList<Food> orderedFoods;
    private double totalPrice;
    private String status;

    public Order() {
        this.orderId = nextOrderId++;
        this.orderedFoods = new ArrayList<>();
        this.totalPrice = 0.0;
        this.status = "Completed"; 
    }

    public void addFood(Food food) {
        this.orderedFoods.add(food);
        this.totalPrice += food.getPrice();
    }

    public int getOrderId() {
        return orderId;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public String getStatus() {
        return status;
    }

    public ArrayList<Food> getOrderedFoods() {
        return orderedFoods;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("--- Order ID: ").append(orderId).append(" ---\n");
        for (Food food : orderedFoods) {
            sb.append("  - ").append(food.getFoodName()).append(" (").append(String.format("%.2f", food.getPrice())).append(" Tk)\n");
        }
        sb.append("Total Price: ").append(String.format("%.2f", totalPrice)).append(" Tk\n");
        sb.append("Status: ").append(status).append("\n");
        return sb.toString();
    }
}
