package Entity;

public abstract class Food{
	private String foodName;
	private double price;
	
	public Food() {}
	
	public Food(String foodName,double price){
		this.foodName=foodName;
		this.price=price;
	}
	
	public  void setFoodName(String foodName){
		this.foodName=foodName;
	}
	public String getFoodName(){
		return foodName;
	}
	public void setPrice(double price){
		this.price=price;
	}
	public double getPrice(){
		return price;
	}
	
	public abstract String getFoodDetails();
}
