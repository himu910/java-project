package File;
import java.io.*;
import java.util.Scanner;

public class FileIO{
	
	
	private static final String FILE_PATH = "orders.txt"; 
	
	public static void saveInFile(String data){
		try{
			File file = new File(FILE_PATH);
			FileWriter writer = new FileWriter(file,true); 
			writer.write(data + "\n");
			writer.close();
		}
		catch(IOException e){
			System.out.println("Cannot Write File");
		}
	}
	
	public static String loadFromFile(){
		try{
			File file = new File(FILE_PATH);
			if(!file.exists()){
				return "File not found: " + FILE_PATH;
			}
			Scanner sc = new Scanner(file);
			StringBuilder data = new StringBuilder();
			while(sc.hasNextLine()){
				data.append(sc.nextLine()).append("\n");
			}
			sc.close();
			return data.toString();
		}
		catch(IOException e){
			System.out.println("Error loading file");
			return "Error loading file";
		}
	}
}
